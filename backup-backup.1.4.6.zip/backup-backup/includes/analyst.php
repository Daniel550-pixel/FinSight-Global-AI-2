<?php

  // Namespace
  namespace BMI\Plugin\Analyst;

  // Exit on direct access
  if (!defined('ABSPATH')) exit;

  // Opt-in child plugin
  require_once BMI_ROOT_DIR . '/analyst/main.php';

  // Initialize the opt-in
  analyst_init(array(
    'client-id' => '6l8b75dw0p3qkv9z',
  	'client-secret' => '94fe452dd8c8cd2482fd0ae0d2532b02aa55b734',
    'base-dir' => BMI_ROOT_FILE
  ));
