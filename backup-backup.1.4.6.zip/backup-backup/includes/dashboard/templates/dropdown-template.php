<?php

  // Namespace
  namespace BMI\Plugin\Dashboard;

  // Exit on direct access
  if (!defined('ABSPATH')) exit;

?>

<div class="bmi-dropdown dropdown-template" data-selected="-1">
  <div class="dropdown-title"></div>
  <div class="dropdown-options"></div>
</div>
